import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-formularioenvio',
  templateUrl: './formularioenvio.component.html',
  styleUrls: ['./formularioenvio.component.css']
})
export class FormularioenvioComponent implements OnInit {
  re = /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
  nt = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4}$/im;

  Anuncio: string | null = "";
  nombre: string | null = null;
  fono: string | null = null;
  email: string | null = null; 
  pais:string|null=null;
  calle:string|null=null;
  ciudad:string|null=null;
  region:string|null=null;
  codigopostal:string|null=null;

  constructor() { }

  ngOnInit(): void {
  }

  insertar(): void {
    this.Anuncio = "";

    if (this.pais != null && this.calle != null && this.nombre != null&& this.ciudad != null&& this.region != null&& this.codigopostal != null) {
      if (this.pais.length != 0 || this.nombre.length != 0 || this.calle.length != 0|| this.ciudad.length != 0|| this.region.length != 0|| this.codigopostal.length != 0) {
        if (this.pais.search(" ") >= 0 || this.nombre.search(" ") >= 0 || this.calle.search(" ") >= 0 || this.ciudad.search(" ") >= 0|| this.region.search(" ") >= 0|| this.codigopostal.search(" ") >= 0) {
          console.log("Espacio en blanco encontrado");
          this.Anuncio = "Carácteres vacios encontrados";
        } else {
          if (this.re.test(this.codigopostal)) {
            console.log("codigo correcto");
            if (this.nt.test(this.region)) {
              console.log("region correcta");
            } else {
              this.Anuncio = (" incorrecto");
            }

          } else {
            console.log("codigo incorrecto");
            this.Anuncio = "incorrecto";
          }
        }
      } else {
        this.Anuncio = "Campos vacios encontrados";
      }
    } else {
      console.log("Espacio en blanco encontrado");
      this.Anuncio = "Campo Vacios";
    }
    console.log("metodo insertar");
    console.log(this.nombre + " " + this.calle + " " + this.ciudad + " " +this.pais + " "+this.region+  " "+this.codigopostal);
  }

} 


