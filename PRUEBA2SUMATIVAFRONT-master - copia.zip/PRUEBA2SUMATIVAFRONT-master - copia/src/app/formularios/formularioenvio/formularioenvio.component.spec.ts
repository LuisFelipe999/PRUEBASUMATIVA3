import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormularioenvioComponent } from './formularioenvio.component';

describe('FormularioenvioComponent', () => {
  let component: FormularioenvioComponent;
  let fixture: ComponentFixture<FormularioenvioComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FormularioenvioComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FormularioenvioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
