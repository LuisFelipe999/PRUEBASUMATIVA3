import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-formulariopago',
  templateUrl: './formulariopago.component.html',
  styleUrls: ['./formulariopago.component.css']
})
export class FormulariopagoComponent implements OnInit {
  re = /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
  nt = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4}$/im;
  Anuncio:string|null="";
  tarjeta: string = "";
  nombre: string = "";
  numerotarjeta:number=0; 
  codigoseguridad:number = 0;
  mesexpiracion: number = 0;
  idArray:number =0;


  arraytarjeta : string[] = [];
  arraynombre: string[] = [];
  arraycodigoseguridad : number[] = [];
  arraynumerotarjeta : number[] = [];
  arraymesexpiracion: number[] = [];
  arrayIds: number[] = [];

  constructor() { }

  ngOnInit(): void {
  }

  subidaValores(): void{
    
    console.log("Carga");
    this.arrayIds.push(this.idArray);
    this.arraytarjeta.push(this.tarjeta);
    this.arraynombre.push(this.nombre);
    this.arraynumerotarjeta.push(this.numerotarjeta);
    this.arraymesexpiracion.push(this.mesexpiracion);

    this.idArray++;

  }
  eliminarDeTabla(id: number|any,): void {

    let index = this.arraytarjeta.indexOf(id);
    this.arraytarjeta.splice(index, 1);

    index = this.arraynombre.indexOf(id);
    this.arraynombre.splice(index, 1);

    index = this.arraycodigoseguridad.indexOf(id);
    this.arraycodigoseguridad.splice(index, 1);

    index = this.arraynumerotarjeta.indexOf(id);
    this.arraynumerotarjeta.splice(index, 1);

    index = this.arrayIds.indexOf(id);
    this.arrayIds.splice(index, 1);
  }


  insertar(): void {
    this.Anuncio = "";

    if (this.tarjeta != null && this.numerotarjeta != null && this.codigoseguridad != null&& this.mesexpiracion != null&& this.nombre != null) {
     
      console.log("incorrecto");
        
        } else {
            console.log("correcto");
          
              console.log("correcta");
           

}  



  } 
  
  

  

} 


