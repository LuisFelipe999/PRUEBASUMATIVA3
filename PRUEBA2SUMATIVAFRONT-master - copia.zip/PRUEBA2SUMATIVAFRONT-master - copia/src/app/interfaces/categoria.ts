export interface Categoria { 

    uvaBlanca:string; 
    uvaNegra:string; 
    


}
