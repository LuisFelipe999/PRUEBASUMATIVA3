import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uvasdemesa',
  templateUrl: './uvasdemesa.component.html',
  styleUrls: ['./uvasdemesa.component.css']
})
export class UvasdemesaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
